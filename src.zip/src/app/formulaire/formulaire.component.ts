import { Component } from '@angular/core';

@Component({
  selector: 'app-formulaire',
  templateUrl: './formulaire.component.html',
  styleUrls: ['./formulaire.component.css']
})
export class FormulaireComponent {
  nom : string = "Nom";
  prenom : string = "Prenom";
  adresse : string = "Adresse";
  cp : string = "Code Postal";
  ville : string = "Ville";
  pays : string = "Pays";
  tel : string = "Numéro de téléphone";
  mail : string = "Adresse mail";
  civi : string = "Civilité";
  user : string = "Nom Utilisateur";
  pass : string = "Mot De Passe";

  valid : boolean = true;

  desactivation(){
    this.valid = false;
  }



}
